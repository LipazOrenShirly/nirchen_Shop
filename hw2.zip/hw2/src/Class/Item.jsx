import React from 'react';
export default class Item {
    
    constructor( id, name, price, image ){
        this.id=id;
        this.name=name;
        this.price=price;
        this.image=image;
    }
    get Id() {return this.id};
    set Id (value){this.id=value;}
    get Name() {return this.name};
    set Name (value){this.name=value;}
    get Price() {return this.price};
    set Priced (value){this.price=value;}
    get Image() {return this.image};
    set Image (value){this.image=value;}
    
    

    show(){return(
    
          <div className="col-md-4 divShow" id={this.Id}>
        <div className="col-md-12"><img className="ImgClass" src={this.Image} /></div>

        <div className="col-md-12">{this.Name}</div>
        <div className="col-md-12">cost: {this.Price}$</div>
            
       </div> 
    )}
}