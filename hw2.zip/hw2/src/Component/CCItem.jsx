import React, {Component} from 'react';
import Item from '../Class/Item';
//import { shallowEqual } from '@babel/types';
import CCItemsInCart from './CCItemsInCart.jsx';
import $ from "jquery";
import CCItems from './CCItems.jsx'
export default class CCItem extends Component{
    
    constructor(props){
        super(props);
    }
    
    clickAdd=()=>{
      this.props.SendDataToItems(this.props.index)
    }
    
    render(){ 
       // this.state.jd="<CCItemsInCart Iname={this.state.xOld.Name} Icost={this.state.xOld.Price} ID={this.state.xOld.Id} ></CCItemsInCart>"
       // $(".ph").append(this.state.jd)
       return(
        <div style = {itemStyle}>
          {console.log(this.props.item)}         
          <img src = {this.props.item.image} style = {imgStyle}></img>
          <h1 style = {nameStyle}>{this.props.item.name}</h1>
          <h2 style = {priceStyle}>{this.props.item.price}$</h2>
          <button className="btn btn-light" onClick={this.clickAdd}>Add</button>
        </div>
    )} 
}

const itemStyle = {
  background: '#f4f4f4',
  textAlign: 'center',
  padding: '5px',
  margin: '5px',
  borderRadius: '5px'
}

const imgStyle = {
  height: '200px',
  borderRadius: '20px'

}

const nameStyle = {
  fontSize: 20
}

const priceStyle = {
  fontSize: 20
}