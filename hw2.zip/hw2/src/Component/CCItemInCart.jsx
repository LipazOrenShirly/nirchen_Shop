import React, {Component} from 'react';
import Item from '../Class/Item';
import CCItemsInCart from './CCItemsInCart.jsx';
import $ from "jquery";
export default class CCItemInCart extends Component{
    
    constructor(props){
        super(props);
    }
    
    clickRemove=()=>{
      this.props.SendDataToItemsInCart(this.props.index)
    }
    
    render(){ 

       return(
        <div style = {itemStyle}>
              <img src = {this.props.item.image} style = {imgStyle}></img>
              <h1 style = {nameStyle}>{this.props.item.name}</h1>
              <h2 style = {priceStyle}>{this.props.item.price}$</h2>        
              <button className="btn btn-light" onClick={this.clickRemove}>Remove</button>
        </div>    
   
    )}  
}

const itemStyle = {
  background: '#f4f4f4',
  textAlign: 'center',
  padding: '5px',
  margin: '5px',
  borderRadius: '5px'
}

const imgStyle = {
  height: '50px',
  borderRadius: '5px'
}

const nameStyle = {
  fontSize: 15
}

const priceStyle = {
  fontSize: 15
}