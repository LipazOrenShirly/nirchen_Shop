import React, {Component} from 'react';
import $ from "jquery";
import Item from '../Class/Item';
import CCItem from './CCItem.jsx';
import CCShop from './CCShop.jsx';
import CCItemInCart from './CCItemInCart';
export default class CCItemsInCart extends Component{
    
    constructor(props){
        super(props);
     

    }
    getDataFromItemInCart= (data) => {
        this.props.SendDataToShop2(data);//לא נותן לעשות סנד
    }

    render(){
        let sum=0;
        return(
            <div>
                <div>
                    { this.props.itemsBuyed.map((item,key)=>
                    <CCItemInCart index={key} item={item} SendDataToItemsInCart={this.getDataFromItemInCart}>    
                    </CCItemInCart>)}
                </div>
                <div style = {totalsStyle}>
                    <p style = {totalStyle}>Total Price:</p>
                    <p>{this.props.SumOfAll}$</p>
                </div>
            </div>
        )}
}

const totalsStyle = {
    background: '#f4f4f4',
    textAlign: 'center',
    padding: '10px',
    margin: '5px',
    borderRadius: '5px',
    fontWeight: 'bold'
}

const totalStyle = {
    textDecorationLine: 'underline'
}