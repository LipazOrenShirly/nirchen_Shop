import React, {Component} from 'react';
import $ from "jquery";
import Item from '../Class/Item'
import CCItem from './CCItem.jsx'
import CCShop from './CCShop.jsx';
export default class CCItems extends Component{
    
    constructor(props){
        super(props);
       
    }
     getDataFromItem = (data) => {
        this.props.SendDataToShop1(data);
    }
    render(){
        
        return(
            <div>               
                {this.props.arrItems.map((item,key) =>
                    < CCItem index={key} item={item} SendDataToItems={this.getDataFromItem}></CCItem>)}
            </div>      
    )}   
}
