import React from 'react';
import { Link } from 'react-router-dom';


function Header() {
  return (
    <div className='container-fluid' style={headerStyle}>
        <div className="row">
            <h1>Shopping</h1>
        </div>
    </div>
  )
}

const headerStyle = {
  background: '#333',
  color: '#fff',
  paddingLeft: '40%',
}

export default Header;