import React, {Component} from 'react';
//import { shallowEqual } from '@babel/types';
export default class CCItem extends Component{
    
    constructor(props){
        super(props);
    }
    
    clickAdd=()=>{
      this.props.SendDataToItems(this.props.index)
    }
    
    render(){ 
       return(
         
        <div style = {itemStyle}>
               {this.props.item.show()}  
          <button className="btn btn-light" onClick={this.clickAdd}>Add</button>
        </div>
    )} 
}
const itemStyle = {
  background: '#f4f4f4',
  textAlign: 'center',
  padding: '5px',
  margin: '5px',
  borderRadius: '5px'
}

