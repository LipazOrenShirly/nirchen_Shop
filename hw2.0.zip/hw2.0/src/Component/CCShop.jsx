import React, {Component} from 'react';
import CCItems from './CCItems.jsx';
import Item from '../Class/Item';
import CCItemsInCart from './CCItemsInCart';


export default class CCShop extends Component{
    
    constructor(props){
        super(props);
        this.state={
            itemsInCart:[],
            arrItems:[
                new Item(1,"T-Shirt",10,"https://images.asos-media.com/products/new-look-organic-v-neck-tee-in-black/12869890-1-black?$XXL$&wid=513&fit=constrain"),
                new Item(2,"Hat",20,"https://images-na.ssl-images-amazon.com/images/I/61VO-9GI8nL._UX679_.jpg"),
                new Item(3,"Jeans",15,"https://images.asos-media.com/products/asos-design-ridley-high-waisted-skinny-jeans-in-extreme-dark-stonewash-blue/9828919-1-darkstonewash?$n_320w$&wid=317&fit=constrain"),
            ],
            sum:0
        } 
    }
    getDataFromItems = (data) =>{//הוצאה מהמלאי והכנסה לעגלה
        let arrNew = this.state.itemsInCart;
        arrNew.push(this.state.arrItems[data])//תכניס למערך הפריטים בעגלה את הפריט שהוצא מהמלאי
       this.setState({itemsInCart:arrNew});
       let sum1=this.state.sum + this.state.arrItems[data].Price;
       this.setState({sum:sum1})
       let newArr2 = this.state.arrItems;
       newArr2.splice(data,1);//תוריד מהמערך של הפריטים במלאי את הערך שהוצא
       this.setState({arrItems:newArr2})
    }
    getDataFromItemsInCart =(data)=>{//הוצאה מהעגלה והכנסה למלאי חזרה
        let newArr1 = this.state.arrItems;
        newArr1.unshift(this.state.itemsInCart[data]);
        this.setState({arrItems:newArr1});
        let sum2=this.state.sum-this.state.itemsInCart[data].Price;
        this.setState({sum:sum2});
        let arrNew1 = this.state.itemsInCart;
        arrNew1.splice(data,1);
        this.setState({itemsInCart:arrNew1});       
    }
    render(){    
        return(
        <div className='container-fluid' style = {containerStyle}>
                <div className = "row">
                    <div className="col-md-9" style = {shopHeaderStyle}>
                        <h2>Shop</h2>
                    </div>
                    <div className="col-md-3" style = {shopHeaderStyle}>
                        <h2>Cart</h2>
                    </div>
                </div>
                <div className = "row">
                    <div className="col-md-9">
                        <CCItems arrItems={this.state.arrItems} SendDataToShop1={this.getDataFromItems}></CCItems>
                    </div>
                    <div className="col-md-3">
                        <CCItemsInCart SumOfAll={this.state.sum} itemsBuyed={this.state.itemsInCart} SendDataToShop2={this.getDataFromItemsInCart} ></CCItemsInCart>
                    </div>
               </div>
        </div>
    )}
}
const containerStyle = {
    background: '#fff',
}
const shopHeaderStyle = {
    background: '#a9a9a9',
    color: '#fff',
    textAlign: 'center',
    paddingTop: '5px',
    margin: '0px',
    borderRight: '4px #fff solid',
}