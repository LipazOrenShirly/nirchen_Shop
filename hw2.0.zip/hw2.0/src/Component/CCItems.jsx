import React, {Component} from 'react';
import CCItem from './CCItem.jsx'
export default class CCItems extends Component{
    
    constructor(props){
        super(props);
       
    }
     getDataFromItem = (data) => {
        this.props.SendDataToShop1(data);
    }
    render(){
        
        return(
            <div>               
                {this.props.arrItems.map((item,key) =>
                    < CCItem index={key} item={item} SendDataToItems={this.getDataFromItem}></CCItem>)}
            </div>      

    )}   
}
