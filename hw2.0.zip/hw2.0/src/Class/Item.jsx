import React from 'react';
export default class Item {
    
    constructor( id, name, price, image ){
        this.id=id;
        this.name=name;
        this.price=price;
        this.image=image;
    }
    get Id() {return this.id};
    set Id (value){this.id=value;}
    get Name() {return this.name};
    set Name (value){this.name=value;}
    get Price() {return this.price};
    set Priced (value){this.price=value;}
    get Image() {return this.image};
    set Image (value){this.image=value;}
    
    

    show(){return(
    
        <div > 
        <img src = {this.Image} style = {imgStyle}></img>
        <h1 style = {nameStyle}>{this.Name}</h1>
        <h2 style = {priceStyle}>{this.Price}$</h2>
      </div>
            
    )}
}

  const imgStyle = {
    height: '200px',
    borderRadius: '20px'
  }
  
  const nameStyle = {
    fontSize: 20
  }
  
  const priceStyle = {
    fontSize: 20
  }