import React from 'react';
import './App.css';
import CCShop from './Component/CCShop';
import Header from './Component/layout/Header';


function App() {
  
  return (
    <div className="App">
      <header className="App-header">
        <Header />
      </header>
      <CCShop/>
    </div>
  );
}

export default App;
